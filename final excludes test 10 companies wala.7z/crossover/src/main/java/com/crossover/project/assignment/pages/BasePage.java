package com.crossover.project.assignment.pages;

import com.crossover.project.assignment.objectrepository.BasePageOR;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class BasePage extends BasePageOR {

    public BasePage(WebDriver driver) {
        super(driver);
        AjaxElementLocatorFactory ajaxElementLocatorFactory = new AjaxElementLocatorFactory(driver, 60);
        PageFactory.initElements(ajaxElementLocatorFactory, this);
    }
}
