package com.crossover.project.assignment.pages;

import com.crossover.project.assignment.objectrepository.JobsPageOR;
import com.crossover.project.assignment.util.DriverUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.logging.Level;
import java.util.logging.Logger;

public class JobsPage extends JobsPageOR {

    private static final Logger logger = Logger.getLogger(String.valueOf(JobsPage.class));
    public JobsPage(WebDriver driver) {
        super(driver);

        if (!(jobTitleKeywords.isDisplayed() && DriverUtils.getDriverUtils().getCurrentUrl()
                .contains("marketplace/available-jobs"))) {
            throw new IllegalStateException("Are you sure about applying jobs in here? Because I can see the page is " +
                    "broken :(");
        }

        logger.log(Level.INFO, "Available Jobs Page is opened.");
    }

    public boolean checkIfJobTitleElementIsFocused() {
        jobTitleKeywords.click();

        if (jobTitleKeywords.getAttribute("placeholder").equalsIgnoreCase(DriverUtils.getDriverUtils()
                .getFocusedElement().getAttribute("placeholder"))) {
            return true;
        }

        return false;
    }

    public JobsPage inputJobText(String value) {
        jobTitleKeywords.sendKeys(value);

        if (!jobTitleKeywords.getAttribute("value").equalsIgnoreCase(value)) {
            throw new IllegalStateException("The text that is entered does not match with what is present in text box.");
        }
        return this;
    }

    public JobsPage validateSearchPageShowsCorrectResult(String text) {
        searchButton.click();
        if (!DriverUtils.getDriverUtils().isElementDisplayed(containingKeywordsMessage)) {
            throw new IllegalStateException("Seems, the search did not retrieve any information for keyword: " + text);
        }

        return this;
    }

    public JobsPage resetSearchFilters() {
        resetButton.click();

        if (!jobTitleKeywords.getAttribute("value").isEmpty()) {
            throw new IllegalStateException("Seems reset is not working as expected.");
        }
        return this;
    }

    public JobsPage selectJobCategory(String category) {

        try {
            allJobCategoriesSelect.click();
        } catch (Exception e) {
            logger.log(Level.WARNING, "Seems, the all jobs category field is already clicked.");
        }
        allJobCategoriesSelectInput.sendKeys(category);
        driver.findElement(By.xpath("//span[text()='" + category + "']")).click();
        return this;
    }

    public JobsPage validateAllJobsCategorySelectBox() {
        allJobCategoriesSelect.click();

        if (!DriverUtils.getDriverUtils().isElementDisplayed(listOfJobCategories)) {
            throw new IllegalStateException("Seems, the list of categories has not yet populated");
        }

        return this;
    }

    public JobsPage selectJobCategoryAndValidateResult(String category) {

        selectJobCategory(category);

        if (!DriverUtils.getDriverUtils().isElementDisplayed(containingCategoryMessage)) {
            throw new IllegalStateException("Seems, the search did not retrieve any information for category: " + category);
        }

        return this;
    }
}
