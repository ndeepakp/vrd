package com.crossover.project.assignment.objectrepository;

import com.crossover.project.assignment.pages.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class JobsPageOR extends BasePage{

    public JobsPageOR(WebDriver driver) {
        super(driver);
    }

    @FindBy (css = "input[placeholder='Job title, keywords']")
    protected WebElement jobTitleKeywords;

    @FindBy (css = "button[class='btn btn-success']")
    protected WebElement searchButton;

    @FindBy (css = "button[ng-click='filterReset()']")
    protected WebElement resetButton;

    @FindBy (css = "div[placeholder*='Select or search']+input")
    protected WebElement allJobCategoriesSelectInput;

    @FindBy (css = "div[placeholder*='Select or search']")
    protected WebElement allJobCategoriesSelect;

    @FindBy (css = "ul[class*='ui-select-choices ui-select-choices-content ui-select-dropdown dropdown-menu ng-scope']" +
            " li div[class*='ui-select-choices-row']")
    protected WebElement listOfJobCategories;

    @FindBy (xpath = "//span[contains(text(), 'containing keywords')]/preceding::span[contains(text(),'Showing')]")
    protected WebElement containingKeywordsMessage;

    @FindBy (xpath = "//span[contains(text(), 'category')]/preceding::span[contains(text(),'Showing')]")
    protected WebElement containingCategoryMessage;
}