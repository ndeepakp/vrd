import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"src/features/sampleFeature.feature"},
        glue = {"classpath:com.crossover.project.assignment.step_definitions"},
        format = { "pretty", "html:target/site/cucumber-pretty", "json:target/cucumber.json" },
        monochrome = true,
        tags = "@Trigger"
)
public class TestRunner {

}
