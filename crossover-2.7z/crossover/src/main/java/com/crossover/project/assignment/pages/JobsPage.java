package com.crossover.project.assignment.pages;

import com.crossover.project.assignment.objectrepository.JobsPageOR;
import com.crossover.project.assignment.util.DriverUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.logging.Level;
import java.util.logging.Logger;

public class JobsPage extends JobsPageOR {

    private static final Logger logger = Logger.getLogger(String.valueOf(JobsPage.class));
    public JobsPage(WebDriver driver) {
        super(driver);

        if (!(jobTitleKeywords.isDisplayed() && DriverUtils.getDriverUtils().getCurrentUrl()
                .contains("marketplace/available-jobs"))) {
            throw new IllegalStateException("Are you sure about applying jobs in here? Because I can see the page is " +
                    "broken :(");
        }

        logger.log(Level.INFO, "Available Jobs Page is opened.");
    }

    public boolean checkIfJobTitleElementIsFocused() {
        jobTitleKeywords.click();

        if (jobTitleKeywords.getAttribute("placeholder").equalsIgnoreCase(DriverUtils.getDriverUtils()
                .getFocusedElement().getAttribute("placeholder"))) {
            return true;
        }

        return false;
    }

    public void inputJobText(String value) {
        jobTitleKeywords.sendKeys(value);

        if (!jobTitleKeywords.getAttribute("value").equalsIgnoreCase(value)) {
            throw new IllegalStateException("The text that is entered does not match with what is present in text box.");
        }
    }

    public void validateSearchPageShowsCorrectResult(String text) {
        searchButton.click();
        if (!DriverUtils.getDriverUtils().isElementDisplayed(containingKeywordsMessage)) {
            throw new IllegalStateException("Seems, the search did not retrieve any information for keyword: " + text);
        }
    }

    public void resetSearchFilters() {
        resetButton.click();

        if (!jobTitleKeywords.getAttribute("value").isEmpty()) {
            throw new IllegalStateException("Seems reset is not working as expected.");
        }
    }
}
