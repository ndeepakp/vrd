package com.crossover.project.assignment.pages;

import com.crossover.project.assignment.objectrepository.HomePageOR;
import com.crossover.project.assignment.util.DriverUtils;
import org.openqa.selenium.WebDriver;

public class HomePage extends HomePageOR {

    public HomePage(WebDriver driver) {
        super(driver);

        if (!loginButton.isDisplayed()) {
            throw new IllegalStateException("This is not the home page for crosover. Are you already logged in? Or is " +
                    "it the wrong website or the mobile view?");
        }

    }

    public JobsPage navigateToAvailableJobsPage() {
        DriverUtils.getDriverUtils().scrollInToView(availableJobsLink);
        availableJobsLink.click();
        return new JobsPage(DriverUtils.getDriverUtils().switchToWindow("available-jobs"));
    }
}
