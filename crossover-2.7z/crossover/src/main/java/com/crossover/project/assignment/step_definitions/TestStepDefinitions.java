package com.crossover.project.assignment.step_definitions;

import com.crossover.project.assignment.pages.HomePage;
import com.crossover.project.assignment.pages.JobsPage;
import com.crossover.project.assignment.util.CommonUtils;
import com.crossover.project.assignment.util.DriverUtils;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TestStepDefinitions{
    private static final Logger logger = Logger.getLogger(String.valueOf(TestStepDefinitions.class));

    DriverUtils driverUtils;
    HomePage homePage = null;
    JobsPage jobsPage = null;

    @Before
    public void createDriverUtils() throws IOException {
        driverUtils = DriverUtils.getDriverUtils();
    }

    @Given("^I open the crossover website \"([^\"]*)\"$")
    public void I_open_the_crossover_website(String url) {
        if (url.trim().isEmpty())
            driverUtils.goTo(CommonUtils.getCommonUtilsInstance().getProperties().getProperty("url"));
        else
            driverUtils.goTo(url);
    }

    @Then("^I check the home page of crossover is opened$")
    public void I_check_the_home_page_of_crossover_is_opened() {
        homePage = new HomePage(driverUtils.getWebDriverInstance());
    }

    @Then("^I navigate to the jobs page and validate the same$")
    public void I_navigate_to_jobs_page() {
        jobsPage = homePage.navigateToAvailableJobsPage();
    }

    @Then("^I click on the job title field and validate the focus is set or not$")
    public void I_validate_the_focus_on_job_title_element() {
        jobsPage.checkIfJobTitleElementIsFocused();
    }

    @Then("^I close the current window$")
    public void I_close_the_available_jobs_page() {
        DriverUtils.getDriverUtils().closeDriver();
        DriverUtils.getDriverUtils().switchToWindow("crossover");
    }

    @Given("^I search for \"([^\"]*)\" in the job titles keyword$")
    public void I_search_for_job_titles(String text) {
        jobsPage.inputJobText(text);
    }

    @Given("^I validate the search result is for \"([^\"]*)\"$")
    public void I_validate_search_for(String text) {
        jobsPage.validateSearchPageShowsCorrectResult(text);
    }

    @Then("^I reset the search filters and validate default jobs page$")
    public void I_reset_search_filters_and_validate_default() {
        jobsPage.resetSearchFilters();
    }
}