package com.crossover.project.assignment.objectrepository;

import com.crossover.project.assignment.pages.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class HomePageOR extends BasePage{

    public HomePageOR(WebDriver driver) {
        super(driver);
    }

    @FindBy (css = "div[id=desktopNav] ul li.external-link a[href*='login']")
    protected WebElement loginButton;

    @FindBy (css = "div[class*='sqs-block'] p a[href*='available-jobs']")
    protected WebElement availableJobsLink;
}
