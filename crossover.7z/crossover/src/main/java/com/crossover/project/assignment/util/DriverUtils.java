package com.crossover.project.assignment.util;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DriverUtils {

    private static DriverUtils driverUtils;
    private WebDriver driver;
    private static final Logger logger = Logger.getLogger(String.valueOf(DriverUtils.class));

    private DriverUtils(String browserType) {
        this.driver = getDriverInstance(browserType);
    }

    public static DriverUtils getDriverUtils() {

        if (driverUtils == null) {
            logger.log(Level.INFO, "Creating an instance of browser: " + CommonUtils.getCommonUtilsInstance().
                    getProperties().getProperty("browser"));
            driverUtils = new DriverUtils(CommonUtils.getCommonUtilsInstance().getProperties().getProperty("browser"));
        } else {
            logger.log(Level.INFO, "Using existing driver session of browser: " + CommonUtils.getCommonUtilsInstance().
                    getProperties().getProperty("browser"));
        }
        return driverUtils;
    }

    private WebDriver getDriverInstance(String browser) {

        WebDriver driver = null;
        switch (browser.trim().toLowerCase()) {
            case "firefox":
                driver = new FirefoxDriver();
                break;
            case "chrome":
            default:
                System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
                driver = new ChromeDriver();
        }

        return driver;
    }

    public WebDriver getWebDriverInstance() {
        return driver;
    }

    public WebDriver goTo(String url) {
        driver.navigate().to(url);
        return driver;
    }

    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    public void quitDriver() {
        driver.quit();
        driver = null;
        driverUtils = null;
    }

    public void closeDriver() {
        driver.close();
    }

    public boolean isElementDisplayed(WebElement element) {

        try {
            return element.isDisplayed();
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.getLocalizedMessage());
            return false;
        }
    }

    public WebElement findElement(By byLocator) {
        return driver.findElement(byLocator);
    }

    public List<WebElement> findElements(By byLocator) {
        return driver.findElements(byLocator);
    }

    public WebElement getFocusedElement() {
        return driver.switchTo().activeElement();
    }

    private Object executeJavaScript(String script, WebElement element) {
        Object obj = ((JavascriptExecutor) getWebDriverInstance()).executeScript(script, new Object[]{element});
        return obj;
    }

    public void scrollInToView(WebElement element) {
        executeJavaScript("arguments[0].scrollIntoView(true);", element);
    }

    public WebDriver switchToWindow(String url) {
        Iterator<String> windowIterator = driver.getWindowHandles().iterator();
        while (windowIterator.hasNext()) {
            String windowHandle = windowIterator.next();
            WebDriver popup = driver.switchTo().window(windowHandle);
            if (popup.getCurrentUrl().contains(url)) {
                break;
            }
        }
        return driver;
    }
}
