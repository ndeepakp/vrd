package com.crossover.project.assignment.objectrepository;

import com.crossover.project.assignment.pages.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class JobsPageOR extends BasePage{

    public JobsPageOR(WebDriver driver) {
        super(driver);
    }

    @FindBy (css = "input[placeholder='Job title, keywords']")
    protected WebElement jobTitleKeywords;
}
