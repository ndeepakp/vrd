package com.crossover.project.assignment.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class CommonUtils {

    private Properties properties = new Properties();
    private static CommonUtils commonUtils;

    private CommonUtils() throws IOException {
        InputStream input = new FileInputStream("src\\main\\resources\\config.properties");
        properties.load(input);

    }

    public static CommonUtils getCommonUtilsInstance() {
        if (commonUtils == null) {
            try {
                commonUtils = new CommonUtils();
            } catch (IOException e) {
                throw new IllegalStateException(e.getLocalizedMessage());
            }
        }

        return commonUtils;
    }

    public Properties getProperties() {
        return properties;
    }
}