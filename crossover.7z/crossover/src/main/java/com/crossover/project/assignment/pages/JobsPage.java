package com.crossover.project.assignment.pages;

import com.crossover.project.assignment.objectrepository.JobsPageOR;
import com.crossover.project.assignment.util.DriverUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.logging.Level;
import java.util.logging.Logger;

public class JobsPage extends JobsPageOR {

    private static final Logger logger = Logger.getLogger(String.valueOf(JobsPage.class));
    public JobsPage(WebDriver driver) {
        super(driver);

        if (!(jobTitleKeywords.isDisplayed() && DriverUtils.getDriverUtils().getCurrentUrl()
                .contains("marketplace/available-jobs"))) {
            throw new IllegalStateException("Are you sure about applying jobs in here? Because I can see the page is " +
                    "broken :(");
        }

        logger.log(Level.INFO, "Available Jobs Page is opened.");
    }

    public boolean checkIfJobTitleElementIsFocused() {
        jobTitleKeywords.click();

        if (jobTitleKeywords.getAttribute("placeholder").equalsIgnoreCase(DriverUtils.getDriverUtils()
                .getFocusedElement().getAttribute("placeholder"))) {
            return true;
        }

        return false;
    }
}
