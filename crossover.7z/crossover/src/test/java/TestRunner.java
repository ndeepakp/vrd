import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"src/features/sampleFeature.feature"},
        glue = {"classpath:com.crossover.project.assignment.step_definitions"},
        monochrome = true
)
public class TestRunner {

}
